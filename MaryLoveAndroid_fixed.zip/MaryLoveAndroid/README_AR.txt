لعبة رسالة إلى ماري — مشروع أندرويد

هذا مشروع مصدر جاهز للاستيراد في Android Studio أو AndroidIDE، وليس ملف APK مبنيًا بالفعل.

طريقة البناء:
1) فك ضغط MaryLoveAndroid.zip.
2) افتح المجلد MaryLoveAndroid في Android Studio أو AndroidIDE.
3) وافق على تنزيل أدوات Gradle وAndroid SDK إذا طُلب منك ذلك.
4) من قائمة Build اختر Build APK(s).
5) ستجد ملف APK عادةً داخل:
   app/build/outputs/apk/debug/app-debug.apk

ملاحظات:
- اسم التطبيق: رسالة إلى ماري
- معرّف التطبيق: com.mary.love
- لا يحتاج إلى صلاحيات أو اتصال بالإنترنت.
- يتطلب بيئة بناء أندرويد حديثة. لا يمكن تثبيت هذا المشروع مباشرة؛ يجب بناء APK أولًا.
